# Yi Ding — Personal Website

A simple, free, mobile-friendly personal website for GitHub Pages. No build tools, hosting subscription, or coding software needed.

## What is inside?

- `index.html` — all website words and links. Edit this file to update your story, research, or contact links.
- `styles.css` — design, layout, fonts, and colors.
- `script.js` — mobile menu and automatic year in the footer.
- `.nojekyll` — tells GitHub Pages to publish these files as-is.

## Publish on GitHub Pages

1. Sign in to https://github.com (create a free account if needed).
2. Create a **public** repository named `YOUR-GITHUB-USERNAME.github.io` (replace with your exact username). Do NOT initialize it with an automatic license if you prefer a clean upload.
3. In the new repository, choose **Add file → Upload files**.
4. Upload **the files inside this folder**, not the ZIP and not the enclosing folder itself. Commit the changes to `main`.
5. Go to **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, then select `main` and `/ (root)`. Save.
6. Visit `https://YOUR-GITHUB-USERNAME.github.io`. Publication may take several minutes.

## Update the website without coding tools

1. Open your repository on GitHub and click `index.html`.
2. Click the pencil / Edit this file icon.
3. Find the paragraph or heading you want to change. Edit text **between the HTML tags**, e.g. `<p>Your text here</p>`.
4. Click **Commit changes**. The live site will update after GitHub Pages republishes.

## Before making this public

- Read every section, especially the proposed personal journey wording. Your personal experiences are not fully documented by the CV.
- In the Journey section, replace the clearly marked placeholder `[Personal story to be written and approved by Yi.]` with something in your own voice (or remove that sentence until ready).
- If you add personal photographs, only publish photos you have permission to share.
- The uploaded academic CV is **not** included because it contains a phone number and details tailored to a specific application. Add a public-facing CV later if you want.
- An email address is **not** included by default; visitors can contact you using LinkedIn. Email can be added later if you choose.
- The site uses Google Fonts; if unavailable, the browser will show fallback fonts.

## Cost

Free with a public repository on GitHub Free, using the standard `github.io` address. A separate domain name is optional and normally paid.

## Source and factual review

Research/education timeline, academic roles, and publications adapted from Yi Ding's uploaded 2026 CV. LinkedIn is linked, but its live content was not available for direct verification.
